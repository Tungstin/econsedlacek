% AUTOCOV_AR1_GENERAL returns autocovariance matrix for the AR1_GENERAL process X_t 
% 
% INPUTS:
%   t       time period range
%   params  model parameters (see GMM_AR1_GENERAL) 
%
% RETURNS:
%   returns returns lower triangular matrix for Var[X_t]
%
function val = autocov_ar1_general(t, params)
    rho_u = params(1);
    rho_v = params(2);
    rho_w = params(3);
    sig_theta = params(4);
    sig_utilde = params(5);
    sig_vtilde = params(6);
    sig_eps = params(7);
    sig_z = params(8);
    
    % if t = 0:T, returns lower triangle of T+1 x T+1 matrix 
    % Var[X_t] =    | Cov[X_0,X_0]                               |
    %               | Cov[X_0,X_1] Cov[X_1,X_1]                  |
    %               |  ...                                       |
    %               | Cov[X_0,X_T] Cov[X_1,X_T] ... Cov[X_T,X_T] |  
    %          
    [tpgrid, tgrid] = ndgrid(t,t);
    jgrid = tpgrid-tgrid;

    if ~(rho_u<1 && rho_v < 1 && rho_w <= 1)
        warning('autocov_ar1_general::some persistence is above 1');
    end
    if rho_w == 1
        rho_w = rho_w - 1e-12; % approximate with just below unit root to use working vectorized formula
    end
       
    val =  tril( ...
        sig_utilde^2*rho_u.^(2*(tgrid+1)+jgrid) + ...
        sig_theta^2*(1-rho_u.^(tgrid+1))/(1-rho_u).*(1-rho_u.^(tgrid+1+jgrid))/(1-rho_u) + ...
        sig_vtilde^2*rho_v.^(2*(tgrid+1)+jgrid) + ...
        sig_eps^2*rho_w.^jgrid.*(1-rho_w.^(2*(tgrid+1)))/(1-rho_w^2) + ...
        sig_z^2*0.^jgrid);
            
end

