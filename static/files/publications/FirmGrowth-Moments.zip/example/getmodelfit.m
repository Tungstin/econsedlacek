% GETMODELFIT calculate several measures of modelfit
% USAGE
%   [RMSE, AIC, RMSEdf] = getmodelfit(autocov, @model, thetahat0) 
% INPUTS
%   autocov         K length vector with lower diagonal of autocovariance matrix
%   modelfcn           pointer to residual function for model
%   params          1 x L vector of model's L parameters 
%
% OUTPUTS
%   MODELFIT        structure with following fields
%       RMSE            sqrt of MSE computed without df adjustment
%       MAD             mean absolute deviation
%       AIC             Akaike Information Criterion
%       RMSEdf          sqrt of MSE computed with df adjustment
%       R2              R-squared
%       R2a             Adjusted R-squared
%
function [modelfit] = getmodelfit(autocovvec, leads, modelfcn, params)

K = length(autocovvec);
[N,L] = size(params);
assert (N==1, 'getmodelfit::multiple parameter vectors specified');

resid = modelfcn(autocovvec, leads, params);
modelfit.SSE = resid'*resid;
modelfit.RMSE = sqrt(modelfit.SSE/K);
modelfit.RMSEdf = sqrt(modelfit.SSE/(K-L));
modelfit.MAE = sum(abs(resid))/K;
modelfit.AIC = K*log(K*modelfit.MAE) + 2*L;
modelfit.R2 = 1-modelfit.SSE/K;
modelfit.R2a = 1-modelfit.SSE/(K-L);

end
