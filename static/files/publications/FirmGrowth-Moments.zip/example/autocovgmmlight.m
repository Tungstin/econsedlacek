% AUTOCOVGMMLIGHT Estimate model parameters from sample autocovariance using GMM
% USAGE
%   [thetahat] = autocovgmm(autocov, leads, @model, thetahat0, [weights]) 
% INPUTS
%   autocov         K length vector with lower diagonal of autocovariance matrix
%   leads           maximum number of leads for autocovariance
%   model           pointer to residual function for model
%   THETAHAT0       N x L matrix initial guess of L parameters for N
%                   alternative initial conditions
%   [weights]       optional weighting matrix for GMM estimation
%   [usehybrid=1]   1 if try to improve each guess with deriv free solver
%   [Aeq]           L x L vector of restrictions A x = b
%   [beq]           L x 1 vector if restrictions A x = b
%   [lb]            1 x L vector of lower bounds
%   [ub]            1 x L vector of upper bounds

%
% OUTPUTS
%   thetahat        vector of estimated model parameters
%   modelfit        struct with various model fit fields
%   allmse          vector of MSE for each guess
%
function [thetahat, modelfit, xfvals] = autocovgmmlight(sample_autocov, leads, model, thetahat0, varargin)

num_moments = (leads+2)*(leads+1)/2;
assert(num_moments == length(sample_autocov), 'autocovariance vector doesn''t match number of leads');

[n_guesses, n_params] = size(thetahat0);

% defaults 
weights = eye(num_moments);
usehybrid = 0;
% constraints
Aeq = [];
beq = [];
lb = [];
ub = [];

% override defaults if optional arguments supplied
% optargs = {weights, A, b};
optargs = {weights, usehybrid, Aeq, beq, lb, ub};
for i=1:length(varargin)
    if ~isempty(varargin{i})
        optargs{i} = varargin{i};
    end
end
weights = optargs{1};
usehybrid = optargs{2};
Aeq = optargs{3};
beq = optargs{4};
lb = optargs{5};
ub = optargs{6};

optsfminu = optimset('TolX',1e-6,'TolFun',1e-8, 'MaxIter', 1000,'Display','off');
optsfminu = optimset(optsfminu, 'MaxFunEvals', 1e4);
optsfminc = optsfminu;
% one or the other: sqp/interior-point (default)
optsfminc = optimset(optsfminc, 'Algorithm', 'sqp');
% optsfminc = optimset(optsfminc, 'Algorithm', 'active-set');
optsfmins = optimset(optsfminu, 'LargeScale', 'off');

objective = @(x0)gmm_residual(sample_autocov, leads, model, weights, x0);

xfvals = zeros(n_guesses,1);
xthetahats = zeros(n_guesses,n_params);
for i=1:n_guesses
    if (~isempty(Aeq) && ~isempty(beq)) || (~isempty(lb) && ~isempty(ub))
        fprintf(1,'autocovgmm:: use quasi-newton solver for with initial guess %i\n', i);
        [xthetahats(i,:), xfvals(i)] = fmincon(objective,thetahat0(i,:),[], [], Aeq,beq,lb,ub,[], optsfminc);
        % try an unconstrained derivative free solver in case it does better
        fprintf(1,'autocovgmm:: fmincon residual = %8.6f \n', xfvals(i));
        if usehybrid
            fprintf(1,'autocovgmm:: use derivative free solver for with initial guess %i\n', i);
            [thetahat1, fval1] = fminsearch(objective,thetahat0(i,:), optsfmins);
            fprintf(1,'autocovgmm:: initial guess %i: fmincon = %8.6f fminsearch = %8.6f\n', i, xfvals(i), fval1);
            thetahat1c = max(min(thetahat1, ub),lb);
            fval1c = objective(thetahat1c);
            fprintf(1,'autocovgmm:: fminsearch_c = %8.6f\n', fval1c);
            if fval1c < xfvals(i) && checkconstraintAb(Aeq,beq,thetahat1) && checkconstraintlb(lb,thetahat1) && checkconstraintub(ub,thetahat1)
                [xthetahats(i,:), xfvals(i)] = fmincon(objective,thetahat1,Aeq,beq,[],[],lb,ub,[], optsfminc);
                fprintf(1,'autocovgmm:: after fminsearch update--> fmincon = %8.6f\n', xfvals(i));
            end
        end
    else
        % try both a quasi-newton and derivative-free solver
        fprintf(1,'autocovgmm:: use quasi-newton solver for with initial guess %i\n', i);
        [xthetahats(i,:), xfvals(i)] = fminunc(objective,thetahat0(i,:),optsfminu);
        fprintf(1,'autocovgmm:: fminunc residual = %8.6f \n', xfvals(i));
        if usehybrid
            fprintf(1,'autocovgmm:: use derivative free solver for with initial guess %i\n', i);
            [thetahat1, fval1] = fminsearch(objective,thetahat0(i,:),optsfmins);
            fprintf(1,'autocovgmm:: initial guess %i: fminunc = %8.6f fminsearch = %8.6f\n', i, xfvals(i), fval1);    
            % when the derivative-free solver does better, run the quasi-newton 
            % solver one more time from an updated initial guess
            if fval1 < xfvals(i)
                [xthetahats(i,:), xfvals(i)] = fminunc(objective,thetahat1,optsfminu);
                fprintf(1,'autocovgmm:: after fminsearch update--> fminunc = %8.6f\n', xfvals(i));
            end
        end
    end
end

if n_guesses > 1
    [f, xi] = min(xfvals);
    fprintf(1,'Smallest local minimum %8.10f found with guess %i\n', f, xi);
    thetahat = xthetahats(xi,:);
else
    thetahat = xthetahats;
end

modelfit = getmodelfit(sample_autocov, leads, model, thetahat);

end

function mse = gmm_residual(autocovvec, num_leads, model, weights, x0)
    sample_moments = model(autocovvec, num_leads, x0);
    mse = sample_moments'*weights*sample_moments;
end

function val = checkconstraintAb(A,b,x)
    if ~isempty(A) && ~isempty(b)
        val = all(A*x(:) == b);
    else
        val = true;
    end
end

function val = checkconstraintlb(lb,x)
    if ~isempty(lb)
        val = all(x(:) >= lb(:));
    else
        val = true;
    end
end
    
function val = checkconstraintub(ub,x)
    if ~isempty(ub)
        val = all(x(:) <= ub(:));
    else
        val = true;
    end
end
