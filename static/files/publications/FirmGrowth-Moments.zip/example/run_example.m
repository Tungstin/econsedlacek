%% CHOOSE ESTABLISHMENT OR FIRM AUTOCOV AND BALANCED OR UNBALANCED PANEL
autocov_type = 2; % 1 = establishments, 2 = firms
sample_type = 2; % 1 = unbalanced, 2 = balanced


%% READ AUTOCOV MATRICES FROM SAVED EXCEL FILES
base_var = 'ln_emp_res_cohortind';
autocov_files = {'../data/autocov_establishments.xls', '../data/autocov_firms.xls'};
autocov_names = {'Establishments', 'Firms'};
sample_names = {'Unbalanced', 'Balanced'};
sample_labels = {'', '_bal'};
max_age = 19; % age includes 0
autocov_matrix = zeros(max_age+1,max_age+1);
autocov_name = [autocov_names{autocov_type}, ' ', sample_names{sample_type}];

tmpvec = xlsread(autocov_files{autocov_type}, [base_var, sample_labels{sample_type}, '_vec']);
assert(length(tmpvec) == (max_age + 1)*(max_age + 2)/2);
index_tril = tril(reshape(1:(max_age+1)^2,max_age+1,max_age+1))>0; % indices of lower triangle
autocov_matrix(index_tril) = tmpvec;


%% GMM POINT ESTIMATES FROM BENCHMARK AUTOCOVARIANCE VECTOR

% each row is an initial guess for the 8 params
THETA_0 = [0.6,0.9,0.9,0.1,0.1,0.1,0.1,0.1;];

% baseline model       
[params_ar1_general, modelfit_ar1_general] = autocovgmmlight(autocov_matrix(index_tril),max_age,@gmm_ar1_general, THETA_0,[]);

% hopenhayn and rogerson (1993) model (restricted model I in the paper)
getresid = @(autocovvec, leads, x0) gmm_ar1_general(autocovvec, leads, ...
    [x0(1),x0(1),x0(1),0,0,x0(2),x0(3),0]);
[params_HR, modelfit_HR] = autocovgmmlight(autocov_matrix(index_tril),max_age,getresid, THETA_0(:,[3,6,7]));

fprintf(1,'MODEL       rho_u    rho_v    rho_w    sig_th   sig_u    sig_v    sig_eps  sig_z    RMSE\n');
fprintf(1,'--------------------------------------------------------------------------------------------------------\n');
fprintf(1,'AR1_GEN     %6.4f   %6.4f   %6.4f   %6.4f   %6.4f   %6.4f   %6.4f   %6.4f   %6.4f   \n',[params_ar1_general(1:3),abs(params_ar1_general(4:8))], modelfit_ar1_general.RMSE);
fprintf(1,'AR1_HR      %6.4f   %6.4f   %6.4f   %6.4f   %6.4f   %6.4f   %6.4f   %6.4f   %6.4f   \n',[params_HR([1,1,1]),0,0,abs(params_HR([2,3])),0], modelfit_HR.RMSE);


%% AUTOCOVARIANCE FUNCTIONS DATA / MODEL


set(groot,'DefaultTextInterpreter','Latex')
set(groot, 'DefaultAxesTickLabelInterpreter','Latex')
set(groot,'DefaultTextFontSize',10)
set(groot,'DefaultAxesFontSize',10)

figure
subplot(1,2,1) % baseline model
model_autocov = autocov_ar1_general(0:max_age,params_ar1_general);
hold on
for i=1:max_age+1
    plot((i-1):max_age,autocov_matrix(i:end,i),'-ok','LineWidth',1.25);
    plot((i-1):max_age,model_autocov(i:end,i),'-xb','LineWidth',1.25);
end
hold off
text(1,1.2,sprintf('RMSE = %0.4f',modelfit_ar1_general.RMSE),'FontSize',10)
legend('data', 'baseline model','location','southwest');
legend boxoff
xlabel('firm age')
ylabel('autocovariance of log employment')
title(['baseline ar(1) (',autocov_names{autocov_type},' ', sample_names{sample_type},')'])

subplot(1,2,2) % restricted model
model_autocov = autocov_ar1_general(0:max_age,[params_HR([1,1,1]),0,0,abs(params_HR([2,3])),0]);
hold on
for i=1:max_age+1
    plot((i-1):max_age,autocov_matrix(i:end,i),'-ok','LineWidth',1.25);
    plot((i-1):max_age,model_autocov(i:end,i),'-xb','LineWidth',1.25);
end
hold off
text(1,1.2,sprintf('RMSE = %0.4f',modelfit_HR.RMSE),'FontSize',10)
legend('data', 'restricted model','location','southwest');
legend boxoff
xlabel('firm age')
ylabel('autocovariance of log employment')
title(['baseline ar(1) (',autocov_names{autocov_type},' ', sample_names{sample_type},')'])
