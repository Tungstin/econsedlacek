% GMM_AR1_GENERAL sample moments (data - model) for GMM estimation of 
%   AR1_GENERAL process from observed autocovariance vector
%
% MODEL:
% For a >= 0
%   n_ia = u_ia + v_ia + w_ia + z_ia  
%   u_ia = rho_u * u_ia-1 + theta_i 
%   v_ia = rho_v * v_ia-1 
%   w_ia = rho_w * w_ia-1 + eps_ia
% with iid fixed effects
%   theta_i ~ var(theta_i) = sig_theta^2
% iid initial conditions
%   u_i-1 = utilde_i ~ var(utilde_i) = sig_utilde^2
%   v_i-1 = vtilde_i ~ var(vtilde_i) = sig_vtilde^2
%   w_i-1 = 0
% and iid shocks
%   eps_ia ~ var(eps_ia) = sig_eps^2
%   z_ia ~ var(z_ia) = sig_z^2
%
% INPUTS: 
%   autocovvec  vectorized lower triangle of autocovariance matrix
%   leads       number of leads in autocov matrix
%   x0          8 x 1 initial guess containing in order:
%       rho_u
%       rho_v
%       rho_w
%       sig_theta
%       sig_utilde
%       sig_vtilde
%       sig_eps
%       sig_theta
%       sig_z
%
% OUTPUTS:
%   sample_moments  sample autocov minus model autocov
%
% NOTES:
%
function [sample_moments] = gmm_ar1_general(autocovvec, leads, x0)
% sample moments formed from distance between sample autocovariance and
% parameterized autocovariance
num_moments = (leads+1+1)*(leads+1)/2;
sample_moments = zeros(num_moments, 1);
moment_index = 1;
assert(length(x0) == 8);
assert(length(autocovvec) == num_moments);
rho_u = x0(1);
rho_v = x0(2);
rho_w = x0(3);
sig_theta = x0(4);
sig_utilde = x0(5);
sig_vtilde = x0(6);
sig_eps = x0(7);
sig_z = x0(8);
for i = 0:leads
    for j = 0:(leads-i)
        sample_moments(moment_index) = autocovvec(moment_index) - ...
            sig_utilde^2*rho_u^(2*(i+1)+j) - ...
            sig_theta^2*polyval(ones(1,i+1),rho_u)*polyval(ones(1,i+1+j),rho_u) - ... (robust to rho_u == 1)
            sig_vtilde^2*rho_v^(2*(i+1)+j) - ...
            sig_eps^2*rho_w^j*polyval(ones(1,i+1),rho_w^2) - ... (robust to rho_w == 1)
            sig_z^2*0^j;
        moment_index = moment_index + 1;
    end
end
end