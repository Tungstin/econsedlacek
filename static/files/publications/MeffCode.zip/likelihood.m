function L = likelihood(X0,X,Y,thp,Pp,X2,par)

% This function runs the Kalman filter and delivers the negative of the
% likelihood (L). 
%
%==========================================================================
% Structure: Input: X0  - vector of parameters to be maximized over 
%                   X   - regressors
%                   Y   - observables
%                   thp - initial state
%                   Pp  - initial state covariance matrix
%                   X2  - control variables (including 1s for const. in
%                   state eq.)
%                   par - parameter structure
%            Ouput: L   - negative of the likelihood
%
% Hamiltons notation:
% 
% y_t = A'*x_t + H'*chi_t + eps_t,          eps_t~N(0,R)
% chi_t = F*chi_{t-1} + G'*D_t + ups_t,     ups_t~N(0,Q)
%==========================================================================

% Defining parameters
%---------------------

ssp = form_ss(X0,X,X2,par);

% Kalman filter routine
[thf, thf_1, Ptt, Ptt_1, like, Z, Vt, etat] = Kfilter(ssp.X1,Y,thp,Pp, ...
    ssp.Q,ssp.R,ssp.H,ssp.A,ssp.F,ssp.G,ssp.D,ssp.C,ssp.M);


L = - like;
