function [thf, thf_1, Ptt, Ptt_1, like, Z, Vt, etat] = Kfilter(X,Y,thp,Pp,Q,R,H,A,F,G,D,C,M)

% Kalman filter. The notation follows Hamilton:
%
% y_t = A'*x_t + H'*chi_t + eps_t,          eps_t~N(0,R)
% chi_{t+1} = F*chi_t + G'*D_t + ups_{t+1},     ups_t~N(0,Q)
%
%==========================================================================
% Structure: Input:  X   - matrix of regressors (lxT)
%                    Y   - matrix of dependent variables (Txk)
%                    thp - initial value for state mean (px1)
%                    Pp  - initial value for state MSE (pxpx1)
%                    Q   - state innovation variance (pxp)
%                    R   - observation innovation variance (kxk)
%                    H   - coefficients on states in observation eq. (pxk)
%                    A   - coefficients on regressors in obs. eq. (lxk)
%                    F   - state transition matrix (pxp)
%                    G   - coefficients on control in state eq. (mxp)
%                    D   - control variables (mxT)
%                    C   - covariance between obs. and state innov (pxk)
%                    M   - matrix multiplying state innovations
%            Output: thf   - filtered state (updated, theta(t|t))
%                    thf_1 - filtered state (forecasted, theta(t|t-1))
%                    Ptt   - state MSE (updated, P(t|t))
%                    Ptt_1 - state MSE (forecasted, P(t|t-1))
%                    like  - likelihood value
%                    Zt    - variance of prediction errors 
%                    Vt    - prediction errors
%                    etat  - K*V
%==========================================================================

T = max(size(X));
[p,k] = size(H);

Ptt   = zeros(p,p,T);       % P(t|t) 
Ptt_1 = zeros(p,p,T+1);     % P(t+1|t) - need initial value for this P(1|0)
thf   = zeros(p,T);         % theta(t|t) 
thf_1 = zeros(p,T+1);       % theta(t+1|t) - need initial value for this theta(1|0)

% initial values
Ptt_1(:,:,1) = Pp;          % P(1|0)
thf_1(:,1)   = thp;         % thf(1|0)
lik          = zeros(T,1);
Vt           = zeros(k,T+1);

for t=1:T
    Z = H'*Ptt_1(:,:,t)*H + R + H'*C + C'*H;
    V  = Y(:,t) - A'*X(:,t) - H'*thf_1(:,t);
    K  = (Ptt_1(:,:,t)*H + C)*inv(Z);
    thf(:,t)       = thf_1(:,t) + K*V;
    thf_1(:,t+1)   = F*thf(:,t) + G*D(:,t);       % observables in state equation
    Ptt(:,:,t)     = Ptt_1(:,:,t) - K*(H'*Ptt_1(:,:,t) + C');
    Ptt_1(:,:,t+1) = F*Ptt(:,:,t)*F' + M*Q*M';

    Vt(:,t) = V;
    etat(:,t) = K*V;
    lik(t) = -0.5*log(det(Z)) - 0.5*V'*inv(Z)*V;
end

like = sum(lik(2:end)) - T*k/2*log(2*pi); % log-likelihood
