%=============================================================================================================
%             Match efficiency and job search from employment and out of the labor force
%=============================================================================================================


% Petr Sedlacek
% 29.2.2016

% notes: run this file to generate all Tables and Figures in main text.

clc
clear all

tic
%=============================================================================================================
% 1. Load data
%=============================================================================================================

dataFlows   = xlsread('Meff_data','Monthly','B3:D153');     
dataMain    = xlsread('Meff_data','Monthly','E3:I153');
LFs         = xlsread('Meff_data','Monthly','J3:L153');
urate       = xlsread('Meff_data','Monthly','M3:M153');
bcdates     = xlsread('Meff_data','Monthly','N3:N153');
seasons     = xlsread('Meff_data','Monthly','O3:Z153');
disc        = xlsread('Meff_data','Monthly','AA3:AB153');

bcdatesQ    = xlsread('Meff_data','Quarterly','B3:B52');
LFsQ        = xlsread('Meff_data','Quarterly','C3:E52');
vacsQ       = xlsread('Meff_data','Quarterly','F3:F52');

t   = 2001-1/12:1/12:2013+5/12;
tQ  = 2001:0.25:2013.25;
T   = length(t);
TQ  = length(tQ);

%%============================================================================================================
% Figure 1 
%=============================================================================================================

% use deseasoned data, as in estimation

regu = regstats(dataFlows(:,1),seasons(:,1:11));
rege = regstats(dataFlows(:,2),seasons(:,1:11));
regi = regstats(dataFlows(:,3),seasons(:,1:11));

flu  = dataFlows(:,1) - regu.yhat + regu.beta(1);
fle  = dataFlows(:,2) - rege.yhat + rege.beta(1);
fli  = dataFlows(:,3) - regi.yhat + regi.beta(1);
flall = flu + fle + fli;

figure
kkk=jbfill(t,-bcdates',bcdates',[0.7,0.7,0.7],[0.7,0.7,0.7],1,1);
hold on
plot(t,flu./flall*100,'k',t,fle./flall*100,'--r',t,fli./flall*100,'-.b','LineWidth',2)
axis([2000 2014 10 50]), ylabel('percent')
set(get(get(kkk,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off');
legend('from unemployment','from employment','from inactivity',0)
hold off

%%============================================================================================================
% Table 1 
%=============================================================================================================

% Match efficiency without non-unemployed job seekers and using UE flows 

Y       = log(sum(dataFlows(:,1),2)./dataMain(:,3))';   
X       = [log(dataMain(:,3)),log(dataMain(:,2)),seasons(:,1:12)]';

[thsUE,PsUE]= get_ths(Y,X,1);

% Match efficiency without non-unemployed job seekers and using total hires

Y       = log(sum(dataMain(:,1),2)./dataMain(:,3))';    
X       = [log(dataMain(:,3)),log(dataMain(:,2)),seasons(:,1:12)]'; 

[thsH,PsH]= get_ths(Y,X,2);


Y       = [log(sum(dataFlows(:,1:3),2)),log(dataFlows(:,1)./dataMain(:,3))-log(dataFlows(:,2)./dataMain(:,4)), ...
            log(dataFlows(:,1)./dataMain(:,3))-log(dataFlows(:,3)./dataMain(:,5))]';
X       = [log(dataMain(:,3)),log(dataMain(:,4)),log(dataMain(:,5)),log(dataMain(:,2)),seasons(:,1:12)]';

[thsNUS,PsNUS]= get_ths(Y,X,3);

load sspUE, load sspH, load sspNUS, load hessUE, load hessH, load hessNUS

disp('***********Table 1 content***************')
disp('match efficiency estimates and associated st.errs.:')
disp('with non-unemployed job seekers')
disp(sspNUS.muS)
disp(sqrt(1/hessNUS(1,1)))
disp('without non-unemployed job seekers and using total hires')
disp(sspH.muS)
disp(sqrt(1/hessH(1,1)))
disp('without non-unemployed job seekers and using UE flows')
disp(sspUE.muS)
disp(sqrt(1/hessUE(1,1)))

%=============================================================================================================
%% Figure 2
%=============================================================================================================

% Quarterly averages of monthly results
%---------------------------------------

for i = 1:TQ
    thsQ(i,:)   = mean(thsNUS(3*i-2+1:3*i+1,:));
    thsQl(i,:)  = mean(thsNUS(3*i-2+1:3*i+1,:)-[squeeze(sqrt(PsNUS(1,1,3*i-2+1:3*i+1))), ...
                    squeeze(sqrt(PsNUS(2,2,3*i-2+1:3*i+1))),squeeze(sqrt(PsNUS(3,3,3*i-2+1:3*i+1)))]);
    thsQh(i,:)  = mean(thsNUS(3*i-2+1:3*i+1,:)+[squeeze(sqrt(PsNUS(1,1,3*i-2+1:3*i+1))), ...
                    squeeze(sqrt(PsNUS(2,2,3*i-2+1:3*i+1))),squeeze(sqrt(PsNUS(3,3,3*i-2+1:3*i+1)))]);
    thsHQ(i,1)  = mean(thsH(3*i-2+1:3*i+1,:));
    thsHQl(i,1) = mean(thsH(3*i-2+1:3*i+1,:)-squeeze(sqrt(PsH(1,1,3*i-2+1:3*i+1))));
    thsHQh(i,1) = mean(thsH(3*i-2+1:3*i+1,:)+squeeze(sqrt(PsH(1,1,3*i-2+1:3*i+1))));
    thsUEQ(i,1) = mean(thsUE(3*i-2+1:3*i+1,:));
    thsUEQl(i,1)= mean(thsUE(3*i-2+1:3*i+1,:)-squeeze(sqrt(PsUE(1,1,3*i-2+1:3*i+1))));
    thsUEQh(i,1)= mean(thsUE(3*i-2+1:3*i+1,:)+squeeze(sqrt(PsUE(1,1,3*i-2+1:3*i+1))));
    urateQ(i,1) = mean(urate(3*i-2+1:3*i+1,:));
end

figure
kkk=jbfill(tQ,-bcdatesQ',bcdatesQ',[0.7,0.7,0.7],[0.7,0.7,0.7],1,1);
kkk2 = jbfill(tQ,100*(thsQh(:,2)+thsQh(:,1)+log(LFsQ(:,1))-mean(thsQ(:,2)+thsQ(:,1)+log(LFsQ(:,1))))', ...
    100*(thsQl(:,2)+thsQl(:,1)+log(LFsQ(:,1))-mean(thsQ(:,2)+thsQ(:,1)+log(LFsQ(:,1))))',[1,0.95,0.95], ...
      [1,0.,0.],1,1);
kkk3 = jbfill(tQ,100*(thsQh(:,3)+thsQh(:,1)+log(LFsQ(:,3))-mean(thsQ(:,3)+thsQ(:,1)+log(LFsQ(:,3))))', ...
    100*(thsQl(:,3)+thsQl(:,1)+log(LFsQ(:,3))-mean(thsQ(:,3)+thsQ(:,1)+log(LFsQ(:,3))))',[0.85,0.85,1], ...
      [0,0,1],1,1);
hold on
plot(tQ,100*(log(LFsQ(:,2))-mean(log(LFsQ(:,2)))),'k',tQ,100*(thsQ(:,2)+thsQ(:,1)+log(LFsQ(:,1))-mean(thsQ(:,2)+thsQ(:,1)+log(LFsQ(:,1)))),'--r', ...
             tQ,100*(thsQ(:,3)+thsQ(:,1)+log(LFsQ(:,3))-mean(thsQ(:,3)+thsQ(:,1)+log(LFsQ(:,3)))),'-.b', ...
             'LineWidth',2)
set(get(get(kkk,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
set(get(get(kkk2,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
set(get(get(kkk3,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
legend('unemployed','employed (\Phi^E E)','out of labor force (\Phi^I I)',0)
ylabel('percentage deviations from mean')
ylim([-60,60]), xlim([2001 2013.25])
hold off

%=============================================================================================================
%% Figure 3
%=============================================================================================================

figure
kkk=jbfill(tQ,-bcdatesQ',bcdatesQ',[0.7,0.7,0.7],[0.7,0.7,0.7],1,1);

kkk2=jbfill(tQ,(thsQh(:,1)-mean(thsQ(:,1)))'*100,(thsQl(:,1)-mean(thsQ(:,1)))'*100,[0.6,0.6,0.6], ...
      [0,0,0],1,1);  
kkk3= jbfill(tQ,(thsHQh(:,1)-mean(thsHQ(:,1)))'*100,(thsHQl(:,1)-mean(thsHQ(:,1)))'*100,[1,0.95,0.95], ...
      [1,0.,0.],1,1);
kkk4= jbfill(tQ,(thsUEQh(:,1)-mean(thsUEQ(:,1)))'*100,(thsUEQl(:,1)-mean(thsUEQ(:,1)))'*100,[0.85,0.85,1], ...
      [0,0,1],1,1);
hold on
plot(tQ,100*(thsQ(:,1)-mean(thsQ(:,1))),'k',tQ,100*(thsHQ-mean(thsHQ)),'--r',tQ,100*(thsUEQ-mean(thsUEQ)),'-.b','LineWidth',2)
set(get(get(kkk,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
set(get(get(kkk2,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
set(get(get(kkk3,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
set(get(get(kkk4,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
legend('benchmark','ignoring non-unemployed (total hires)','ignoring non-unemployed (UE flows)',0)
ylabel('percentage deviations from mean'),xlim([2001 2013.25])
ylim([-30,30]),xlim([2001 2013.25])
hold off

%=============================================================================================================
%% Figure 4
%=============================================================================================================

% predicted and counterfactual values
[SQ,fpQ,fpHQ,fpUEQ,ucQHl,ucQHh,ucQH,ucQUEl,ucQUEh,ucQUE,ucQl,ucQh,ucQ,thsQ,rhoQ] = ...
                         get_preds(thsNUS,thsUE,thsH,PsNUS,PsUE,PsH,X,seasons,T,TQ,urate,sspNUS,sspUE,sspH);

figure
kkk3= jbfill(tQ(28:end),100*ucQHh(28:end)',100*ucQHl(28:end)',[1,0.95,0.95], ...
      [1,0.,0.],1,1);
kkk4= jbfill(tQ(28:end),100*ucQUEh(28:end)',100*ucQUEl(28:end)',[0.85,0.85,1], ...
      [0,0,1],1,1);
kkk2=jbfill(tQ(28:end),100*ucQh(28:end)',100*ucQl(28:end)',[0.6,0.6,0.6], ...
      [0,0,0],1,1);  
hold on
plot(2007.75:0.25:2013.25,urateQ(28:end),'-kx',2007.75:0.25:2013.25,ucQ(28:end)*100,'k', ...
    2007.75:0.25:2013.25,ucQH(28:end)*100,'--r', ...
    2007.75:0.25:2013.25,ucQUE(28:end)*100,'-.b','LineWidth',2),ylabel('percent')
set(get(get(kkk2,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
set(get(get(kkk3,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
set(get(get(kkk4,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
legend('actual','fixed m^U, benchmark','fixed m^U, ignoring non-unemployed (total hires)','fixed m^U, ignoring non-unemployed (UE flows)',0)
xlim([2007.75 2013.25]), ylim([3.5 10]), box off
hold off

%=============================================================================================================
%% Table 2
%=============================================================================================================

contribs    = get_contribs(thsQ(:,1),fpQ(:,1),LFsQ(:,2),urateQ);
contribsH   = get_contribs(thsHQ,fpHQ,LFsQ(:,2),urateQ);
contribsUE  = get_contribs(thsUEQ,fpUEQ,LFsQ(:,2),urateQ);

disp('***********Table 2 content***************')
disp('contribution of gamU to JFrate volatility: levels, lin.detrend., HP detrend. (benchmark,H,UE)')
disp([contribs(1,:);contribsH(1,:);contribsUE(1,:)])

disp('average contribution of gammaU to unemployment rate fluctuations: levels, lin. det., HP det. (benchmark,H,UE)')
disp([contribs(2,:);contribsH(2,:);contribsUE(2,:)])

%=============================================================================================================
%% Figure 5
%=============================================================================================================

vrateQ  = vacsQ./(vacsQ+LFsQ(:,1))*100;         % vacancy rate

% (flip y and x axis manually after plotting figure)
figure,  
kkk2 = jbfill(vrateQ(27:35)',100*ucQl(27:35)',100*ucQh(27:35)',[0.6,0.6,0.6],[0,0,0],1,1); 
kkk3 = jbfill(vrateQ(35:end)',100*ucQl(35:end)',100*ucQh(35:end)',[0.6,0.6,0.6],[0,0,0],1,1); 
hold on
plot(vrateQ,[urateQ(1:26);NaN(24,1)],'ko',vrateQ,[NaN(26,1);urateQ(27:end)],'-ko', ...
    vrateQ,[NaN(26,1);100*ucQ(27:end)],'--ks','LineWidth',2),xlim([1.5,3.5]),ylim([3,11])
set(get(get(kkk2,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
set(get(get(kkk3,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
ylabel('unemployment rate (%)'),xlabel('vacancy rate (%)'),legend('actual:2001Q1-2007Q3','actual:2007Q4-2013Q2', ...
    'fixed match efficiency:2007Q4-2013Q2',0)
hold off

% correlation between "match efficiency" of inactive and the share of marginally attached and discouraged
% workers in all inactive

d = Detrend([log(disc./repmat(LFs(:,3),1,2)),thsNUS(:,3)+thsNUS(:,1)],129600,1);

cc = corr(d(:,:,1));
disp('corr(Phi^I,(marginally attached)/inactive),corr(Phi^I,corr(discouraged)/inactive)')
disp([cc(3,1:2)])

toc
