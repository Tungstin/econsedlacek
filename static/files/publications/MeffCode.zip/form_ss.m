% This function forms the relevant state-space (matrices).The notation follows Hamilton
%
% y_t = A'*x_t + H'*chi_t + eps_t,          eps_t~N(0,R)
% chi_t = F*chi_{t-1} + G'*D_t + ups_t,     ups_t~N(0,Q)
%==========================================================================
% Input:        X0   - vector of coefs. being maximized
%               X    - regressors
%               X2   - controls (also for const. in state eq.)
%               par  - parameter structure
% Output:       ssp  - structure of parameters (matrices) of the
%                          state-space model

function ssp = form_ss(X0,X,X2,par)

% matching elasticities
ssp.muV = (X0(1));
ssp.muS = 1-ssp.muV;

ssp.dum = X0(2:13);
       
% error variances
ssp.Q   = exp(X0(14));
ssp.R   = exp(X0(15));

ssp.C   = 0;
% transition matrices for states
ssp.G   = zeros(par.m,1);
ssp.F   = eye(par.m);
% regressors
ssp.D   = X2;
ssp.X1  = X;
    
% defining matrices for state-space specificiation
%--------------------------------------------------
ssp.A   = [ssp.muS-1;ssp.muV;ssp.dum'];
ssp.H   = 1;

ssp.G   = 0;
ssp.M   = 1;
