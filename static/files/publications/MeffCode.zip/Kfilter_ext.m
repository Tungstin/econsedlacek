%=========================================================================================
%                   Extended Kalman filter for the case of a CES matching fce
%=========================================================================================

% Petr Sedlacek
% 15.4.2011


function [thf, thf_1, Ptt, Ptt_1, like, Zt, Vt] = Kfilter_ext(X,Y,thp,Pp,Q,R,F,G,D,C,ssp)

% The extended Kalman filter. The notation follows Hamilton:
%
% y_t = A'*x_t + H'*chi_t + eps_t,          eps_t~N(0,R)
% chi_t = F*chi_{t-1} + G'*D_t + ups_t,     ups_t~N(0,Q)
%
% The observation equations are:
% f_t = alpha_t + 1/bet*h(u_t,v_t) + eps_t
% v_t^J = v_t + eps_t,v
% 
% where h(u_t,v_t) = log(exp(u_t)^bet + exp(v_t)^bet) and v_t = log(V_t) and u_t=log(U_t)
%
% the CES function involved is M_t = A[U_t^bet+V_t^bet]^{1/bet}
%==========================================================================
% Structure: Input:  X   - matrix of regressors (3xT)
%                    Y   - matrix of dependent variables (Txk)
%                    thp - initial value for state mean (px1)
%                    Pp  - initial value for state MSE (pxpx1)
%            
%                    Q   - state innovation variance (pxp)
%                    R   - observation innovation variance (kxk)
%                    F   - state transition matrix (pxp)
%                    G   - coefficients on control in state eq. (mxp)
%                    D   - control variables (mxT)
%                    C   - covariance between obs. and state innov (pxk)
%
%            Output: thf   - filtered state (updated, theta(t|t))
%                    thf_1 - filtered state (forecasted, theta(t|t-1))
%                    Ptt   - state MSE (updated, P(t|t))
%                    Ptt_1 - state MSE (forecasted, P(t|t-1))
%                    like  - likelihood value
%                    Zt    - variance of prediction errors 
%                    Vt    - prediction errors
%==========================================================================
T = max(size(X));
p = size(Pp,1);              % number of states
k = size(R,1);              % number of observables

Ptt   = zeros(p,p,T);       % P(t|t) 
Ptt_1 = zeros(p,p,T+1);     % P(t+1|t) - need initial value for this P(1|0)
thf   = zeros(p,T);         % theta(t|t) 
thf_1 = zeros(p,T+1);       % theta(t+1|t) - need initial value for this theta(1|0)
Vt    = zeros(k,T+1);       % residual in measurement equations

% initial values
Ptt_1(:,:,1) = Pp;          % P(1|0)
thf_1(:,1)   = thp;         % thf(1|0)
lik          = zeros(T,1);

for t=1:T
    % define matrices
    
    % total searchers
    S   = exp(X(1,t)) + exp(thf_1(2,t))*exp(X(2,t)) + exp(thf_1(3,t))*exp(X(3,t));

    % observation equations
    h   = [ssp.muS*thf_1(1,t) + ssp.muV*X(4,t) + ssp.muS*log(S) + ssp.dum*X(5:end,t); ...
           - thf_1(2,t) + ssp.dum2*X(5:end,t); ...
           - thf_1(3,t) + ssp.dum3*X(5:end,t)];

    % associated Jacobian
    H   = [ssp.muS,ssp.muS/S*exp(thf_1(2,t))*exp(X(2,t)),ssp.muS/S*exp(thf_1(3,t))*exp(X(3,t)); ...
           0,-1,0; ...
           0,0,-1]';

    % EKF recursions
    Z               = H'*Ptt_1(:,:,t)*H + R + H'*C + C'*H;
    V               = Y(:,t) - h;
    K               = (Ptt_1(:,:,t)*H + C)/(Z);
    thf(:,t)        = thf_1(:,t) + K*V;
    thf_1(:,t+1)    = F*thf(:,t) + G*D(:,t);       
    Ptt(:,:,t)      = Ptt_1(:,:,t) - K*(H'*Ptt_1(:,:,t) + C');
    Ptt_1(:,:,t+1)  = F*Ptt(:,:,t)*F' + Q;

    lik(t)          = -0.5*log(det(Z)) - 0.5*V'/(Z)*V;
    Vt(:,t)         = V;
    Zt(:,:,t)       = Z;
end
% log-likelihood
like = sum(lik(2:end)) - T*k/2*log(2*pi); 
