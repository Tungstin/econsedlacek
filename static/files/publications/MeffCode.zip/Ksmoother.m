

function [ths,Ps] = Ksmoother(thf,thf_1,Ptt,Ptt_1,F)

% Notation follows Hamilton. 

[p,p,T] = size(Ptt);

ths = zeros(p,T);
Ps  = zeros(p,p,T);

ths(:,T)  = thf(:,end);
Ps(:,:,T) = Ptt(:,:,end);

for t=T-1:-1:1
    J         = Ptt(:,:,t)*F'*inv(Ptt_1(:,:,t+1));
    ths(:,t)  = thf(:,t) + J*(ths(:,t+1) - thf_1(:,t+1));
    Ps(:,:,t) = Ptt(:,:,t) + J*(Ps(:,:,t+1)-Ptt_1(:,:,t+1))*J';
end

ths = ths';