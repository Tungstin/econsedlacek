% This function forms the relevant state-space (matrices). The notation follows Hamilton
%
% y_t = A'*x_t + H'*chi_t + eps_t,          eps_t~N(0,R)
% chi_t = F*chi_{t-1} + G'*D_t + ups_t,     ups_t~N(0,Q)
%==========================================================================
% Input:        X0   - vector of coefs. being maximized
%               X    - regressors
%               X2   - controls (also for const. in state eq.)
%               par  - parameter structure
% Output:       ssp  - structure of parameters (matrices) of the
%                          state-space model

function ssp = form_ss_ext(X0,X,X2,par)

% match efficiency is an ARMA(p,q) process
%-------------------------------------------
% matching elasticities
ssp.muV = (X0(1));
ssp.muS = 1-ssp.muV;

% dummy variables - normalized to sum to 0
ssp.dum = X0(2:12);
ssp.dum = [ssp.dum,0-sum(ssp.dum)];
ssp.dum2= X0(13:23);
ssp.dum2= [ssp.dum2,0-sum(ssp.dum2)];
ssp.dum3= X0(24:34);
ssp.dum3= [ssp.dum3,0-sum(ssp.dum3)];

% error variances
ssp.q   = [X0(35),0,0;X0(35+3),X0(35+1),0;X0(35+5),X0(35+4),X0(35+2)];
ssp.r   = [X0(35+6),0,0;X0(35+9),X0(35+7),0;X0(35+11),X0(35+10),X0(35+8)];

ssp.C   = zeros(par.m);

ssp.Q   = ssp.q'*ssp.q;
ssp.R   = ssp.r'*ssp.r;
% transition matrices for states
ssp.G   = zeros(par.m,1);
ssp.F   = eye(par.m);
% regressors
ssp.D   = X2;
ssp.X1  = X;

