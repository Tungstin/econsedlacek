This readme.txt file describes the programs used to generate all tables and figures in the main text of 
"The aggregate matching function and job search from employment and out of the labor force"

Files included:
 	- Detrend: function for detrending
	- form_ss: constructs the state-space form of the models without non-unemployed job seekers
 	- form_ss_ext: constructs the state-space form of the model with non-unemployed job seekers
	- get_contribs: computes the contributions of match efficiency to job finding rate and unemployment fluctuations
	- get_preds: computes predited and quarterly values of several variables
	- get_ths: conducts the maximum likelihood estimation and delivers smoothed states
	- HZmvntest: multivariate normal test
	- jbfill: function for plotting error bands
	- Kfilter: Kalman filter
 	- Kfilter_ext: extended Kalman filter
	- Ksmoother: Kalman smoother
	- likelihood: function constructing the likelihood function of the models without non-unemployed job seekers
	- likelihood_ext: function constructing the likelihood function of the model with non-unemployed job seekers
	- Meff_Main: main file generating all results
	- Meff_data.xlsx: excel file with all data used


The code was run in Matlab R2013b (64-bit), in Windows 8.1 Pro.

Run Meff_Main.m to generate all results in tables and figures in the main text. All other files are used within Meff_Main.m

The computation time is about 2 minutes.