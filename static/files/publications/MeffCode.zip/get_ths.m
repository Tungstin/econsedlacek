% function that runs maximum likelihood and gets smoothed states at ML estimates

function [ths,Ps] = get_ths(Y,X,vers)

T       = length(Y);
par.m   = size(Y,1);
X2      = ones(1,T);

%=============================================================================================================
%% 1. Starting values
%=============================================================================================================

% error variances
resols  = regstats(Y(1,:)',X(1:end-1,:)');
ini.R   = std(resols.r)^2;
ini.Q   = 0.5*ini.R;                            % initial state error variance

% state vector and cov. matrix
Pp  = eye(par.m)*10^5;                          % state cov. matrix
thp = zeros(par.m,1);                           % state vectorarma

%=============================================================================================================
%% 2. Maximum likelihood
%=============================================================================================================

% with (0) and without (1) using non-unemployed job seekers

if vers == 1 || vers == 2
    X0ini = [0.5,zeros(1,par.m*12),sqrt(ini.Q),sqrt(ini.R)];
else 
    X0ini = [0.5,zeros(1,par.m*11),ones(1,3)*sqrt(ini.Q),zeros(1,3),ones(1,3)*sqrt(ini.R),zeros(1,3)];
end

tic
matlabpool('open',4);
options = optimset('Display','iter','MaxFunEvals',30000, ...
    'MaxIter',30000,'TolX',1e-12,'TolFun',1e-12,'UseParallel','always');

if vers == 1 || vers == 2
    [res,fval,exitfl,outp,grad,hess] = fminunc(@(X0)likelihood(X0,X,Y,thp,Pp,X2,par),X0ini,options);
else
    [res,fval,exitfl,outp,grad,hess] = fminunc(@(X0)likelihood_ext(X0,X,Y,thp,Pp,X2,par),X0ini,options);
end
matlabpool('close');
toc

clear Q, clear R, clear q

%=============================================================================================================
%% 3. Backing out smoothed states
%=============================================================================================================

% 4.1 Defining parameters (following notation as in Hamilton)
%-------------------------------------------------------------
if vers == 1 
    ssp = form_ss(res,X,X2,par);
    sspUE = ssp;
    save sspUE sspUE
    hessUE = hess;
    save hessUE hessUE
elseif vers == 2
    ssp = form_ss(res,X,X2,par);
    sspH = ssp;
    save sspH sspH
    hessH = hess;
    save hessH hessH
else
    ssp = form_ss_ext(res,X,X2,par);
    sspNUS = ssp;
    save sspNUS sspNUS
    hessNUS = hess;
    save hessNUS hessNUS
end

% 4.2 Smoothed state estimates
%-------------------------------

% Kalman filter routine
if vers == 1 || vers == 2
    [thf, thf_1, Ptt, Ptt_1, like, Z, Vt, etat] = Kfilter(ssp.X1,Y,thp,Pp, ...
        ssp.Q,ssp.R,ssp.H,ssp.A,ssp.F,ssp.G,ssp.D,ssp.C,ssp.M);
else
    [thf, thf_1, Ptt, Ptt_1, like, Z, V] = Kfilter_ext(ssp.X1,Y,thp,Pp, ...
    ssp.Q,ssp.R,ssp.F,ssp.G,ssp.D,ssp.C,ssp);
end

% Kalman smoothing using the ML estimates
[ths,Ps] = Ksmoother(thf,thf_1,Ptt,Ptt_1,ssp.F);

%=============================================================================================================
%% 5. Diagnositcs
%=============================================================================================================
if vers == 3
% define standardized forecast errors
for t = 1:T
    scale  = chol(Z(:,:,t)^(-1),'lower');
    e(:,t) = scale*V(:,t+1);
end

% normality
HZmvntest(e',0.05)

% homoscedasticity
[vart1,pval1] = vartest2(e(1,1:round(T/3))',e(1,end-round(T/3)+1:end)');
[vart2,pval2] = vartest2(e(2,1:round(T/3))',e(2,end-round(T/3)+1:end)');
[vart3,pval3] = vartest2(e(3,1:round(T/3))',e(3,end-round(T/3)+1:end)');

disp('p-values of homoscedasticity tests:')
disp([pval1,pval2,pval3])

% serial correlation
[qstat1,pval1] = lbqtest(e(1,:)',6);
[qstat2,pval2] = lbqtest(e(2,:)',6);
[qstat3,pval3] = lbqtest(e(3,:)',6);

disp('p-values of autocorrelation tests:')
disp([pval1,pval2,pval3])
end
    

