%--------------------------------------------------------------------------
%                           Function for various detrending
%--------------------------------------------------------------------------

% 06.07.2009
% Petr Sedlacek

%--------------------------------------------------------------------------
% This function takes the columns of the inputed data and detrends them
% with an HP filter (specified lambda), linear, quadratic or cubic
% deterministic trends and returns the respective detrended data. 
% 
% Input:
%               Z       - data matrix (time series in columns) to be 
%                         detrended,(Txk)
%               HP      - value of lambda in HP filter. If 0, then do not
%                         detrend with HP filter
%               Trend   - indicator function, 1: linear, 2: 1 + quadratic, 
%                         3: 1 + 2 + cubic trends
%
% Output:       C       - matrix of detrended data (Txkxm), where m is
%                         number of detrending methods
%--------------------------------------------------------------------------

function C = Detrend(Z, HP, Trend)

[T,k] = size(Z);
x     = (1:1:T)';
C     = zeros(T,k,Trend+1);

if HP > 0
    for i=1:k
        Tr(:,i)  = hpfilter(Z(:,i),HP);
        C(:,i,1) = Z(:,i) - Tr(:,i);
    end
end

for i=1:k
    if Trend > 0
        X = [ones(T,1),x];
        C(:,i,2) = Z(:,i) - X*inv(X'*X)*X'*Z(:,i);
    end
    if Trend > 1
        X = [ones(T,1),x,x.^2];
        C(:,i,3) = Z(:,i) - X*inv(X'*X)*X'*Z(:,i);
    end
    if Trend >2
        X = [ones(T,1),x,x.^2,x.^3];
        C(:,i,4) = Z(:,i) - X*inv(X'*X)*X'*Z(:,i);
    end
end
        
            