% function computing predicted and counterfactual values

function [SQ,fpQ,fpHQ,fpUEQ,ucQHl,ucQHh,ucQH,ucQUEl,ucQUEh,ucQUE,ucQl,ucQh,ucQ,thsQ,rhoQ] = ...
                            get_preds(thsNUS,thsUE,thsH,PsNUS,PsUE,PsH,X,seasons,T,TQ,urate,sspNUS,sspUE,sspH)

% predicted searchers and job finding rate of the unemployed
for t = 1:T
    S(t,1)      = exp(thsNUS(t,1))*exp(X(1,t))+exp(thsNUS(t,2))*exp(thsNUS(t,1))*exp(X(2,t))+ ...
                    exp(thsNUS(t,3))*exp(thsNUS(t,1))*exp(X(3,t));
    fp(t,1)     = thsNUS(t,1) + sspNUS.muV*X(4,t) + (sspNUS.muS-1)*log(S(t)) + mean(sspNUS.dum*seasons');
    fpH(t,1)    = thsH(t) + sspH.muV*X(4,t) + (sspH.muS-1)*X(1,t) + mean(sspH.dum*seasons');
    
    fpUE(t,1)   = thsUE(t) + sspUE.muV*X(4,t) + (sspUE.muS-1)*X(1,t) + mean(sspUE.dum*seasons');
end

% separation rates implied by u-rates and estimate JF rates
rho     = urate.*exp(fp)./(100-urate);
rhoH    = urate.*exp(fpH)./(100-urate);
rhoUE   = urate.*exp(fpUE)./(100-urate);
% counterfactual JF rates based on match efficiency fixed at 2007Nov value
fc      = thsNUS(86,1)+ sspNUS.muV*X(4,:)' + (sspNUS.muS-1)*log(S) + mean(sspNUS.dum*seasons');
fcH     = thsH(86,1)+ sspH.muV*X(4,:)' + (sspH.muS-1)*X(1,:)' + mean(sspH.dum*seasons');
fcUE    = thsUE(86,1)+ sspUE.muV*X(4,:)' + (sspUE.muS-1)*X(1,:)' + mean(sspUE.dum*seasons');

fch     = thsNUS(86,1) + 1.645*sqrt(squeeze(PsNUS(1,1,:))) + sspNUS.muV*X(4,:)' + (sspNUS.muS-1)*log(S) + ...
            mean(sspNUS.dum*seasons');
fcHh    = thsH(86,1) + 1.645*sqrt(squeeze(PsH(1,1,:))) + sspH.muV*X(4,:)' + (sspH.muS-1)*X(1,:)' + mean(sspH.dum*seasons');
fcUEh   = thsUE(86,1) + 1.645*sqrt(squeeze(PsUE(1,1,:))) + sspUE.muV*X(4,:)' + (sspUE.muS-1)*X(1,:)' + mean(sspUE.dum*seasons');

fcl     = thsNUS(86,1) - 1.645*sqrt(squeeze(PsNUS(1,1,:))) + sspNUS.muV*X(4,:)' + (sspNUS.muS-1)*log(S) + ...
            mean(sspNUS.dum*seasons');
fcHl    = thsH(86,1) - 1.645*sqrt(squeeze(PsH(1,1,:))) + sspH.muV*X(4,:)' + (sspH.muS-1)*X(1,:)' + mean(sspH.dum*seasons');
fcUEl   = thsUE(86,1) - 1.645*sqrt(squeeze(PsUE(1,1,:))) + sspUE.muV*X(4,:)' + (sspUE.muS-1)*X(1,:)' + mean(sspUE.dum*seasons');

% implied unemployment rates
uc      = rho./(rho+exp(fc));
ucH     = rhoH./(rhoH+exp(fcH));
ucUE    = rhoUE./(rhoUE+exp(fcUE));

uch     = rho./(rho+exp(fch));
ucHh    = rhoH./(rhoH+exp(fcHh));
ucUEh   = rhoUE./(rhoUE+exp(fcUEh));

ucl     = rho./(rho+exp(fcl));
ucHl    = rhoH./(rhoH+exp(fcHl));
ucUEl   = rhoUE./(rhoUE+exp(fcUEl));

% quarterly averages
for i = 1:TQ
    SQ(i,1)     = mean(S(3*i-2+1:3*i+1,:));
    rhoQ(i,1)   = mean(rho(3*i-2+1:3*i+1,:));
    fpQ(i,:)    = mean(fp(3*i-2+1:3*i+1,:));
    fpHQ(i,:)   = mean(fpH(3*i-2+1:3*i+1,:));
    fpUEQ(i,:)  = mean(fpUE(3*i-2+1:3*i+1,:));
    
    ucQ(i,:)    = mean(uc(3*i-2+1:3*i+1,:));
    ucQH(i,:)   = mean(ucH(3*i-2+1:3*i+1,:));
    ucQUE(i,:)  = mean(ucUE(3*i-2+1:3*i+1,:));
    
    ucQh(i,:)   = mean(uch(3*i-2+1:3*i+1,:));
    ucQHh(i,:)  = mean(ucHh(3*i-2+1:3*i+1,:));
    ucQUEh(i,:) = mean(ucUEh(3*i-2+1:3*i+1,:));
    
    ucQl(i,:)   = mean(ucl(3*i-2+1:3*i+1,:));
    ucQHl(i,:)  = mean(ucHl(3*i-2+1:3*i+1,:));
    ucQUEl(i,:) = mean(ucUEl(3*i-2+1:3*i+1,:));   
    
    thsQ(i,:)   = mean(thsNUS(3*i-2+1:3*i+1,:));
    rhoQ(i,:)   = mean(rho(3*i-2+1:3*i+1,:));
end