% function that computes contributions to variances

function contribs = get_contribs(thsQ,fpQ,U,urateQ)

% job finding rate of the unemployed
d       = Detrend([thsQ,fpQ,U],1600,2);

dfp     = fpQ(2:end,1)-fpQ(1:end-1,1);
cgamU   = cov(dfp,thsQ(2:end,1)-thsQ(1:end-1,1))/var(dfp)*100;
cgamUl  = cov(d(:,1,2),d(:,2,2))/var(d(:,2,2))*100;
cgamUhp = cov(d(:,1,1),d(:,2,1))/var(d(:,2,1))*100;

% unemployment rate

du      = log(urateQ(2:end)/100)-log(urateQ(1:end-1)/100);
dgamU   = (thsQ(2:end,1)-thsQ(1:end-1,1));
cu      = -cov(du,dgamU.*(1-urateQ(1:end-1)/100))/var(du)*100;

d       = Detrend([log(urateQ(2:end)/100),thsQ(2:end,1),urateQ(2:end)/100],129600,2);
cul     = -cov(d(:,1,2),d(:,2,2).*(1-d(:,3,2)))/var(d(:,1,2))*100;
cuhp    = -cov(d(:,1,1),d(:,2,1).*(1-d(:,3,1)))/var(d(:,1,1))*100;

contribs = [cgamU(1,2),cgamUl(1,2),cgamUhp(1,2);cu(1,2),cul(1,2),cuhp(1,2)];